bootstrapbolttheme
==================

Bootstrap Bolt Theme

This theme was created by Mike Scops at pixelswap.fr for Bolt CMS. Feel free to use it for your projects !*


Theme Installation :

1/ Upload all the files in your theme directory.

2/ Set your path theme in the config.yml (you can do it from the bolt admin interface)

3/ And voilà !


Homepage configuration :

To show your own post type on the homepage you need to modify the index.twig template on line 16, change "articles" by what you want.


This theme is fully responsive, so you don't need any mobile template.

*Don't sell it as your own theme.

If you find an issue please tell me !
