Node/Grunt modules for backend's frontend workflow.
